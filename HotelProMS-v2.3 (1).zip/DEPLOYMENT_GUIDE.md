# 🚀 HotelProMS Deployment Guide (Render)

This guide walks you through deploying **HotelProMS** on [Render](https://render.com) using the provided `render.yaml`.

---

## 1. Prerequisites

- A [GitHub](https://github.com) account
- A [Render](https://render.com) account (Free tier available)
- The project code pushed to a public or private GitHub repo

---

## 2. Steps to Deploy

### Step 1: Push Code to GitHub

1. Download the `HotelProMS-v2.x.zip` file and unzip it locally.
2. Initialize a Git repo:

   ```bash
   git init
   git remote add origin https://github.com/<your-username>/hotelproms.git
   git add .
   git commit -m "Initial commit - HotelProMS"
   git push origin main
   ```

---

### Step 2: Connect Render to GitHub

1. Log in to [Render Dashboard](https://dashboard.render.com).
2. Click **New +** → **Blueprint**.
3. Select your repo containing `render.yaml`.
4. Render will auto-detect the blueprint file.

---

### Step 3: Confirm Resources

- **Backend Service** (Django + Gunicorn)
- **Frontend Service** (React build + static hosting)
- **Postgres Database** (Auto-provisioned by `render.yaml`)

---

### Step 4: Deploy

- Click **Apply**.
- Render will provision the database, run migrations, load demo data, and start both frontend & backend services.

---

## 3. Post Deployment

- Backend API → `https://hotelproms-backend.onrender.com`
- Frontend React → `https://hotelproms-frontend.onrender.com`

The frontend will already be linked to the backend API.

---

## 4. Adding More Demo Data

- Access your Render Dashboard → Databases → hotelproms-db.
- Open the SQL console and run insert commands, e.g.:

```sql
INSERT INTO hotelpro_hotel (name, location) VALUES ('Sunset Inn', 'Lagos, Nigeria');
INSERT INTO hotelpro_employee (name, role, hotel_id) VALUES ('Adaobi Ujah', 'Manager', 1);
```

---

## 5. Redeploy on Changes

Each time you push changes to GitHub:

```bash
git add .
git commit -m "Update feature"
git push origin main
```

Render will **auto-redeploy**.

---

✅ You’re live!  
