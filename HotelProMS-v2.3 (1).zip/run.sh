#!/usr/bin/env bash
set -e

echo "🚀 Bootstrapping HotelProMS..."

cd backend

echo "📦 Running migrations..."
python manage.py migrate --noinput

echo "🎨 Collecting static files..."
python manage.py collectstatic --noinput

echo "🌱 Checking if demo data exists..."
python manage.py shell -c "from hotelpro.models import Hotel; import sys; sys.exit(0 if Hotel.objects.exists() else 1)" || python manage.py seed_demo_data

echo "✅ Demo data ready."

echo "🌍 Starting Django server..."
python manage.py runserver 0.0.0.0:8000
